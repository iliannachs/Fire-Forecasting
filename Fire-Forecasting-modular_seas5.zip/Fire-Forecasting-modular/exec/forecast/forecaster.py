"""
SEAS5 ensemble forecasts of burned area with the trained (ERA5-based) model.

For every initialisation in SEAS5_INITIALISATIONS and every ensemble member:
  1. each predictor of the trained model gets a SOURCE (see _plan):
       seas5          ERA5-type predictor whose months are all forecast months
       sib4_forecast  SiB4 predictor taken from the SEAS5-driven SiB4 run
       historical     value of FORECAST_YEAR from the ERA5 / ERA5-driven SiB4
                      fields used for training (e.g. Apr-May biomass pools)
  2. the predictor fields are built, the model predicts per pixel, and the
     regional total is ranked against the observed climatology.

Outputs go to <experiment folder>/seas5_<initialisation name>/.
Expensive per-member reads are cached (outputs/cache) like the other stages.
"""
import os
import traceback
from pathlib import Path

import numpy as np
import pandas as pd
import xarray as xr

from exec.forecast.seas5_reader import MissingForecastData, Seas5Reader
from exec.visualization.forecast_plotter import ForecastPlotter


def percentile_rank(value, reference):
    ref = np.asarray(reference, dtype=float)
    ref = ref[np.isfinite(ref)]
    return 100.0 * np.mean(ref < value) if ref.size else np.nan


def _jsonable(obj):
    """Plain types only, so settings can go into cache keys."""
    if isinstance(obj, dict):
        return {str(k): _jsonable(v) for k, v in obj.items()}
    if isinstance(obj, (list, tuple)):
        return [_jsonable(v) for v in obj]
    if isinstance(obj, Path):
        return str(obj)
    return obj


class SeasonalForecaster:

    def __init__(self, settings, preprocessor, experiment, cache):
        self.s = settings
        self.pre = preprocessor
        self.exp = experiment
        self.cache = cache
        self.reader = Seas5Reader(settings, preprocessor)

    # ------------------------------------------------------------
    # entry point
    # ------------------------------------------------------------
    def run(self, model, feature_cols, annual_totals=None):
        """
        model         : trained XGBRegressor (ModelTrainer.train)
        feature_cols  : feature order used in training
        annual_totals : optional Evaluator.annual_totals(...) output, used for the
                        ERA5-driven reference line / point in the plots
        """
        s = self.s
        if self.pre.burn_05 is None or self.pre.cluster is None:
            self.pre.burned_area_grid()
            self.pre.fire_clusters()

        specs = self._predictor_specs()
        missing = [f for f in feature_cols if f not in specs]
        if missing:
            raise ValueError(f"No predictor definition for model features {missing}")

        # Training fields (cached) for 'historical' predictors and the unit check.
        historical = {**self.pre.meteorology(), **self.pre.sib4()}
        clim = self._climatology()

        for init_name, init in s.SEAS5_INITIALISATIONS.items():
            print(f"\n{'=' * 60}\nSEAS5 forecast {s.FORECAST_YEAR}, initialisation {init_name}\n{'=' * 60}")
            self._run_init(init_name, init, model, feature_cols, specs, historical, clim, annual_totals)

    # ------------------------------------------------------------
    # predictor bookkeeping
    # ------------------------------------------------------------
    def _predictor_specs(self):
        s = self.s
        specs = {n: {**sp, "kind": "era5"} for n, sp in s.ERA5_PREDICTORS.items()}
        if s.USE_SIB4:
            for n, sp in s.SIB4_PREDICTORS_BY_CLUSTER.get(s.CLUSTER_TO_MODEL, {}).items():
                specs[n] = {**sp, "kind": "sib4"}
        return specs

    def _plan(self, init_name, init, feature_cols, specs):
        """Source per predictor (see module docstring)."""
        fc_months = set(init["leads"])
        init_month = init["init_month"]
        pre_season = init.get("sib4_pre_season_from_forecast", False)
        rows = []

        for name in feature_cols:
            sp = specs[name]
            months = set(sp["months"])
            in_fc = months <= fc_months
            disjoint = not (months & fc_months)

            if sp["kind"] == "era5" and in_fc:
                source = "seas5"
            elif sp["kind"] == "sib4" and (in_fc or (pre_season and min(months) >= init_month)):
                source = "sib4_forecast"
            elif disjoint:
                source = "historical"
            else:
                raise ValueError(
                    f"[{init_name}] predictor '{name}' (months {sorted(months)}) only partly "
                    f"overlaps the forecast months {sorted(fc_months)}; split it or change its months."
                )

            after_init = source == "historical" and max(months) >= init_month
            if after_init:
                print(
                    f"  WARNING [{init_name}] '{name}' uses ERA5-driven data for months "
                    f"{sorted(months)}, i.e. after the initialisation month {init_month}. "
                    "This information is not available at forecast time."
                )
            rows.append({
                "feature": name, "kind": sp["kind"], "months": sorted(months),
                "source": source, "uses_data_after_initialisation": after_init,
            })
        return pd.DataFrame(rows)

    # ------------------------------------------------------------
    # climatology of the observed totals
    # ------------------------------------------------------------
    def _cluster_total(self, year):
        burn = self.pre.burn_05
        sel = burn.time.dt.year == year
        if not bool(sel.any()):
            return np.nan
        da = burn.sel(time=sel).isel(time=0)
        return float(da.where(self.pre.cluster == self.s.CLUSTER_TO_MODEL).sum().values)

    def _climatology(self):
        s = self.s
        clim_years = getattr(s, "FORECAST_CLIM_YEARS", list(s.TRAIN_YEARS) + list(s.TEST_YEARS))
        clim = pd.DataFrame({"year": list(clim_years)})
        clim["burned_area"] = [self._cluster_total(y) for y in clim["year"]]
        clim = clim.dropna()
        ref = clim["burned_area"].to_numpy()
        clim["percentile"] = [percentile_rank(v, ref) for v in ref]
        clim["percentile_bin"] = pd.cut(
            clim["percentile"], bins=s.PERCENTILE_BINS, labels=s.PERCENTILE_LABELS,
            include_lowest=True, right=True,
        )
        clim.to_csv(
            self.exp.path(f"observed_climatology_{min(clim_years)}_{max(clim_years)}.csv"),
            index=False,
        )
        return clim

    # ------------------------------------------------------------
    # one initialisation
    # ------------------------------------------------------------
    def _member_fields(self, init_name, init, ens, plan, specs):
        """Forecast fields of one member: SEAS5 met + SiB4 forecast (both cached)."""
        s = self.s
        grid = [s.GRID_RESOLUTION,
                list(map(float, self.pre.burn_05.lat.values)),
                list(map(float, self.pre.burn_05.lon.values))]
        fields = {}
        for source, read in (("seas5", self.reader.met_fields),
                             ("sib4_forecast", self.reader.sib4_fields)):
            names = plan.loc[plan["source"] == source, "feature"].tolist()
            if not names:
                continue
            sub = {n: {k: v for k, v in specs[n].items() if k != "kind"} for n in names}
            key = _jsonable({
                **self.pre._domain_key(), "grid": grid, "year": s.FORECAST_YEAR,
                "init": init, "ensemble": ens, "specs": sub,
                "seas5_root": getattr(s, "SEAS5_ROOT", None),
                "seas5_pattern": getattr(s, "SEAS5_FILE_PATTERN", None),
                "sib4_pattern": getattr(s, "SIB4_FORECAST_FILE_PATTERN", None),
                "variables": getattr(s, "SEAS5_VARIABLES", None),
                "factors": getattr(s, "SEAS5_UNIT_FACTORS", None),
                "tmax": getattr(s, "SEAS5_TMAX", "monthly_mean"),
            })
            fields.update(self.cache.get_or_compute(
                f"{source}_{init_name}_ens{ens}", key,
                lambda read=read, sub=sub: read(init, ens, sub),
            ))
        return fields

    def _run_init(self, init_name, init, model, feature_cols, specs, historical, clim, annual_totals):
        s = self.s
        outdir = Path(self.exp.path(f"seas5_{init_name}"))
        outdir.mkdir(parents=True, exist_ok=True)

        plan = self._plan(init_name, init, feature_cols, specs)
        plan.to_csv(outdir / "predictor_sources.csv", index=False)
        print(plan[["feature", "months", "source"]].to_string(index=False))

        # Fixed fields of the forecast year (identical for all members).
        fixed = {}
        for name in plan.loc[plan["source"] == "historical", "feature"]:
            da = historical[name]
            sel = da.time.dt.year == s.FORECAST_YEAR
            if not bool(sel.any()):
                raise RuntimeError(f"No {s.FORECAST_YEAR} data for historical predictor '{name}'.")
            fixed[name] = self.pre._safe_2d(da.sel(time=sel).isel(time=0))

        clim_ref = clim["burned_area"].to_numpy()
        totals, pixels, member_means = [], [], []

        for ens in s.FORECAST_ENSEMBLES:
            try:
                fc = self._member_fields(init_name, init, ens, plan, specs)
            except MissingForecastData as exc:
                print(f"  ens{ens}: skipped ({exc})")
                continue
            except Exception as exc:   # keep going with the other members
                print(f"  ens{ens}: FAILED {exc!r}")
                traceback.print_exc()
                continue

            data_vars = {"cluster": self.pre.cluster, **fixed}
            data_vars.update({n: self.pre._safe_2d(da) for n, da in fc.items()})
            frame = (
                xr.Dataset(data_vars).to_dataframe(dim_order=["lat", "lon"]).reset_index()
                [["lat", "lon", "cluster"] + feature_cols]
                .replace([np.inf, -np.inf], np.nan).dropna()
            )
            frame = frame[frame["cluster"].astype(int) == s.CLUSTER_TO_MODEL].copy()
            if frame.empty:
                print(f"  ens{ens}: no valid pixels")
                continue

            frame["predicted"] = np.clip(model.predict(frame[feature_cols]), 0, None)
            total = float(frame["predicted"].sum())
            pct = percentile_rank(total, clim_ref)
            totals.append({
                "year": s.FORECAST_YEAR, "initialisation": init_name, "ensemble": ens,
                "n_prediction_pixels": len(frame), "predicted_total_ha": total,
                "percentile": pct,
            })
            frame.insert(0, "ensemble", ens)
            pixels.append(frame[["ensemble", "lat", "lon", "predicted"]])
            member_means.append({"ensemble": ens, **frame[[f for f in fc]].mean().to_dict()})
            print(f"  ens{ens}: {total:,.1f} ha | percentile {pct:.1f}")

        if not totals:
            print(f"[{init_name}] no ensemble member could be predicted; nothing written.")
            return

        ens_df = pd.DataFrame(totals)
        ens_df["percentile_bin"] = pd.cut(
            ens_df["percentile"], bins=s.PERCENTILE_BINS, labels=s.PERCENTILE_LABELS,
            include_lowest=True, right=True,
        )
        pixel_df = pd.concat(pixels, ignore_index=True)
        y = s.FORECAST_YEAR
        ens_df.to_csv(outdir / f"ensemble_predictions_{y}.csv", index=False)
        pixel_df.to_csv(outdir / f"ensemble_pixel_predictions_{y}.csv", index=False)

        chance = (ens_df.groupby("percentile_bin", observed=False).size()
                  .reindex(s.PERCENTILE_LABELS, fill_value=0).rename("n_ensembles").reset_index())
        chance["chance_percent"] = 100 * chance["n_ensembles"] / len(ens_df)
        chance.to_csv(outdir / f"ensemble_percentile_bin_chances_{y}.csv", index=False)

        observed = self._cluster_total(y)
        era5_ref = (float(annual_totals.loc[y, "predicted"])
                    if annual_totals is not None and y in annual_totals.index else np.nan)
        vals = ens_df["predicted_total_ha"]
        pd.DataFrame([{
            "cluster": s.CLUSTER_TO_MODEL, "experiment": s.EXPERIMENT_NAME,
            "initialisation": init_name, "year": y,
            "successful_ensembles": len(ens_df),
            "mean_predicted_total_ha": vals.mean(),
            "median_predicted_total_ha": vals.median(),
            "p10_predicted_total_ha": vals.quantile(0.1),
            "p90_predicted_total_ha": vals.quantile(0.9),
            "min_predicted_total_ha": vals.min(),
            "max_predicted_total_ha": vals.max(),
            "mean_percentile": ens_df["percentile"].mean(),
            "observed_total_ha": observed,
            "observed_percentile": percentile_rank(observed, clim_ref),
            "era5_driven_predicted_total_ha": era5_ref,
        }]).to_csv(outdir / f"ensemble_summary_{y}.csv", index=False)

        self._consistency_check(outdir, member_means, historical, feature_cols)

        plotter = ForecastPlotter(s, outdir, init_name)
        plotter.spaghetti(ens_df, clim, annual_totals, observed, era5_ref)
        plotter.violin(ens_df, observed, era5_ref)
        plotter.percentile_bins(ens_df)
        plotter.spatial_mean(pixel_df, self.pre.burn_05)
        print(f"[{init_name}] outputs written to {outdir}")

    # ------------------------------------------------------------
    # forecast vs training predictor ranges
    # ------------------------------------------------------------
    def _consistency_check(self, outdir, member_means, historical, feature_cols):
        """
        Cluster-mean value of every forecast predictor (SEAS5 / SiB4 forecast),
        next to the ERA5-driven training range. A forecast far outside that range
        usually means a unit or aggregation mismatch (see SEAS5_UNIT_FACTORS).
        """
        s = self.s
        mask = self.pre.cluster == s.CLUSTER_TO_MODEL
        members = pd.DataFrame(member_means).drop(columns="ensemble")
        rows = []
        for name in members.columns:
            da = historical[name].where(mask)
            train = da.sel(time=da.time.dt.year.isin(s.TRAIN_YEARS)).mean(["lat", "lon"]).values
            same_year = da.sel(time=da.time.dt.year == s.FORECAST_YEAR)
            ref = float(same_year.mean().values) if same_year.sizes["time"] else np.nan
            fc_mean = float(members[name].mean())
            lo, hi = float(np.nanmin(train)), float(np.nanmax(train))
            span = max(hi - lo, 1e-12)
            rows.append({
                "feature": name,
                "train_min": lo, "train_mean": float(np.nanmean(train)), "train_max": hi,
                "era5_driven_forecast_year": ref,
                "forecast_ensemble_mean": fc_mean,
                "forecast_member_min": float(members[name].min()),
                "forecast_member_max": float(members[name].max()),
                "suspicious": bool(fc_mean < lo - span or fc_mean > hi + span),
            })
        check = pd.DataFrame(rows)
        check.to_csv(outdir / f"predictor_consistency_{s.FORECAST_YEAR}.csv", index=False)
        bad = check.loc[check["suspicious"], "feature"].tolist()
        if bad:
            print(
                f"  WARNING: forecast predictors far outside the training range: {bad}. "
                "Check units (SEAS5_UNIT_FACTORS) in predictor_consistency_*.csv."
            )
