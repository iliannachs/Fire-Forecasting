"""
Reading of SEAS5 meteorology and SiB4 seasonal-forecast output for ONE
ensemble member of ONE initialisation, turned into yearly predictor fields on
the burned-area grid (same form as Preprocessor.meteorology() / .sib4()).

Unit and aggregation conventions are chosen to match the ERA5 training data
of the modular pipeline (see "Consistency with ERA5" in the README):
  * t2m, d2m, tmax are returned in KELVIN (the modular ERA5 reader keeps Kelvin);
  * hourly SEAS5 data are first averaged to MONTHLY means (the ERA5 file is
    monthly), derived variables (vpd, tmax) are then computed from the monthly
    means exactly as DataReader.read_era5 does, and finally the same
    seasonal_agg(months, agg) as for ERA5 is applied;
  * an optional per-variable factor (SEAS5_UNIT_FACTORS) converts SEAS5 units
    to ERA5 units (e.g. precipitation).
"""
import os

import numpy as np
import pandas as pd
import xarray as xr

from exec.data.reader import mask_fill_values
from exec.preprocessing.preprocessor import (
    build_pft_field_from_nlu,
    parse_label,
    seasonal_agg,
    to_latlon_grid,
)


class MissingForecastData(Exception):
    """A file or variable of an ensemble member is missing; the member is skipped."""


# Raw SEAS5 names tried for each base variable (SiB4 driver names first).
DEFAULT_SEAS5_VARIABLES = {
    "t2m": ["tm", "t2m"],
    "d2m": ["d2m"],            # if absent, derived from specific humidity 'sh' + 'ps'
    "tp": ["tp"],              # if absent, lspr(_scaled) + cupr(_scaled)
    "windspeed": ["spdm", "windspeed"],   # if absent, sqrt(u10^2 + v10^2)
}

# Variables that are derived and therefore need other base variables.
DERIVED = {"vpd": ("t2m", "d2m"), "tmax": ("t2m",)}


def _first_present(ds, names):
    return next((n for n in names if n in ds.data_vars), None)


def _to_kelvin(da):
    return da + 273.15 if float(da.mean(skipna=True)) < 100.0 else da


def dewpoint_from_specific_humidity(q, ps):
    """
    Dewpoint (Kelvin) from specific humidity q and surface pressure ps.
    q in kg/kg (g/kg is detected and converted); ps in Pa or hPa (detected).
    Inverse of the Magnus formula used for vpd in DataReader.read_era5.
    """
    if float(q.mean(skipna=True)) > 1.0:          # g/kg -> kg/kg
        q = q / 1000.0
    if float(ps.mean(skipna=True)) < 2000.0:      # hPa -> Pa
        ps = ps * 100.0
    e_kpa = (q * ps / (0.622 + 0.378 * q)) / 1000.0
    ln = np.log(e_kpa.clip(min=1e-6) / 0.6108)
    return 237.3 * ln / (17.27 - ln) + 273.15


def vpd_from_kelvin(t2m_k, d2m_k):
    """Same formula as DataReader.read_era5 (kPa, clipped at 0)."""
    t = t2m_k - 273.15
    d = d2m_k - 273.15
    es = 0.6108 * np.exp((17.27 * t) / (t + 237.3))
    ea = 0.6108 * np.exp((17.27 * d) / (d + 237.3))
    return (es - ea).clip(min=0)


class Seas5Reader:
    """Builds forecast predictor fields for one initialisation and ensemble member."""

    def __init__(self, settings, preprocessor):
        self.s = settings
        self.pre = preprocessor
        self.variables = {**DEFAULT_SEAS5_VARIABLES, **getattr(settings, "SEAS5_VARIABLES", {})}
        self.factors = getattr(settings, "SEAS5_UNIT_FACTORS", {})
        self.tmax_mode = getattr(settings, "SEAS5_TMAX", "monthly_mean")
        if self.tmax_mode not in ("monthly_mean", "daily_max"):
            raise ValueError(f"Unknown SEAS5_TMAX: {self.tmax_mode}")

    # ------------------------------------------------------------
    # paths
    # ------------------------------------------------------------
    def seas5_path(self, init, month, ens):
        s = self.s
        lead = init["leads"][month]
        rel = s.SEAS5_FILE_PATTERN.format(
            year=s.FORECAST_YEAR, month=month, lead=lead, ens=ens
        )
        return os.path.join(str(init.get("seas5_root", s.SEAS5_ROOT)), rel)

    def sib4_path(self, init, month, ens):
        s = self.s
        fname = s.SIB4_FORECAST_FILE_PATTERN.format(year=s.FORECAST_YEAR, month=month, ens=ens)
        return os.path.join(str(init["sib4_dir"]), fname)

    # ------------------------------------------------------------
    # spatial helpers
    # ------------------------------------------------------------
    def _to_grid(self, da, ds):
        """SiB4 land points (nsib/landpoints) or lat/lon grid -> sorted lat/lon over Iberia."""
        s = self.s
        rename = {k: v for k, v in (("latitude", "lat"), ("longitude", "lon"))
                  if k in da.dims or k in da.coords}
        da = da.rename(rename) if rename else da

        point_dim = next((d for d in ("nsib", "landpoints") if d in da.dims), None)
        if point_dim is not None:
            lat, lon = ds["latsib"], ds["lonsib"]
            if point_dim in lat.dims:
                lat = lat.isel({d: 0 for d in lat.dims if d != point_dim})
                lon = lon.isel({d: 0 for d in lon.dims if d != point_dim})
            lat_v = np.asarray(lat.values).reshape(-1)
            lon_v = np.asarray(lon.values).reshape(-1)
            if len(lat_v) != da.sizes[point_dim]:
                raise ValueError("SEAS5 latsib/lonsib length does not match the land points.")
            da = (
                da.assign_coords(lat=(point_dim, lat_v), lon=(point_dim, lon_v))
                .set_index({point_dim: ["lat", "lon"]})
                .unstack(point_dim)
            )

        if float(da.lon.max()) > 180:
            da = da.assign_coords(lon=((da.lon + 180) % 360) - 180)
        da = da.sortby("lat").sortby("lon")
        # One degree margin so the nearest-neighbour step has data at the edges.
        return da.sel(
            lon=slice(s.IBERIA_LON_MIN - 1, s.IBERIA_LON_MAX + 1),
            lat=slice(s.IBERIA_LAT_MIN - 1, s.IBERIA_LAT_MAX + 1),
        )

    # ------------------------------------------------------------
    # SEAS5 meteorology
    # ------------------------------------------------------------
    def _open_month(self, path, month):
        if not os.path.exists(path):
            raise MissingForecastData(f"missing SEAS5 file {path}")
        ds = xr.open_dataset(path, decode_times=False)
        if "valid_time" in ds.coords and "time" not in ds.coords:
            ds = ds.rename({"valid_time": "time"})
        n = ds.sizes.get("time", 0)
        if n == 0:
            ds.close()
            raise MissingForecastData(f"no time steps in {path}")
        # Hourly time axis, as in the original SEAS5 scripts.
        return ds.assign_coords(time=pd.date_range(
            start=f"{self.s.FORECAST_YEAR}-{month:02d}-01 00:30:00", periods=n, freq="1h"
        ))

    def _raw(self, ds, var):
        """Hourly base variable on the lat/lon grid, in ERA5 units."""
        src = _first_present(ds, self.variables.get(var, [var]))
        if src is not None:
            da = mask_fill_values(ds[src])
        elif var == "tp" and {"lspr_scaled", "cupr_scaled"} <= set(ds.data_vars):
            da = mask_fill_values(ds["lspr_scaled"]) + mask_fill_values(ds["cupr_scaled"])
        elif var == "tp" and {"lspr", "cupr"} <= set(ds.data_vars):
            da = mask_fill_values(ds["lspr"]) + mask_fill_values(ds["cupr"])
        elif var == "d2m" and {"sh", "ps"} <= set(ds.data_vars):
            da = dewpoint_from_specific_humidity(
                mask_fill_values(ds["sh"]), mask_fill_values(ds["ps"])
            )
        elif var == "windspeed" and {"u10", "v10"} <= set(ds.data_vars):
            da = np.sqrt(mask_fill_values(ds["u10"]) ** 2 + mask_fill_values(ds["v10"]) ** 2)
        else:
            raise MissingForecastData(
                f"SEAS5 variable '{var}' not found (tried {self.variables.get(var, [var])}); "
                f"available: {list(ds.data_vars)}"
            )

        da = self._to_grid(da, ds)
        if var in ("t2m", "d2m"):
            da = _to_kelvin(da)
        return da * self.factors.get(var, 1.0)

    def met_fields(self, init, ens, specs):
        """
        {feature name: DataArray(time=1, lat, lon)} for the ERA5-type predictors
        in `specs` ({name: {"variable", "months", "agg"}}), from SEAS5.
        """
        variables = {spec.get("variable", name) for name, spec in specs.items()}
        base = set()
        for v in variables:
            base.update(DERIVED.get(v, (v,)))
        months = sorted({m for spec in specs.values() for m in spec["months"]})

        monthly = {v: [] for v in base}
        tmax_daily = []
        for month in months:
            ds = self._open_month(self.seas5_path(init, month, ens), month)
            try:
                stamp = pd.Timestamp(f"{self.s.FORECAST_YEAR}-{month:02d}-01")
                for v in base:
                    hourly = self._raw(ds, v).load()
                    monthly[v].append(hourly.mean("time").expand_dims(time=[stamp]))
                    if v == "t2m" and "tmax" in variables and self.tmax_mode == "daily_max":
                        tmax_daily.append(
                            hourly.resample(time="1D").max().mean("time").expand_dims(time=[stamp])
                        )
            finally:
                ds.close()

        fields = {v: xr.concat(parts, dim="time") for v, parts in monthly.items()}
        if "vpd" in variables:
            fields["vpd"] = vpd_from_kelvin(fields["t2m"], fields["d2m"])
        if "tmax" in variables:
            # ERA5 'tmax' on monthly data equals monthly t2m (see README notes).
            fields["tmax"] = (xr.concat(tmax_daily, dim="time")
                              if self.tmax_mode == "daily_max" else fields["t2m"])

        out = {}
        for name, spec in specs.items():
            da = fields[spec.get("variable", name)]
            da_year = seasonal_agg(da, list(spec["months"]), agg=spec.get("agg", "mean"))
            out[name] = self.pre._align_to_burn_grid(da_year).load()
        return out

    # ------------------------------------------------------------
    # SiB4 forecast
    # ------------------------------------------------------------
    def sib4_fields(self, init, ens, specs):
        """
        {feature name: DataArray(time=1, lat, lon)} for the SiB4 predictors in
        `specs`, from the SiB4 run driven by this SEAS5 member. Processing is
        identical to Preprocessor.sib4().
        """
        s = self.s
        months = sorted({m for spec in specs.values() for m in spec["months"]})
        files = [self.sib4_path(init, m, ens) for m in months]
        missing = [f for f in files if not os.path.exists(f)]
        if missing:
            raise MissingForecastData(f"missing SiB4 forecast files: {missing}")

        needed = {parse_label(spec.get("variable", n))[0] for n, spec in specs.items()}
        keep = ["latsib", "lonsib", "lu_area", "lu_pref", "pft_names", "pft_refnums"] + sorted(needed)
        with xr.open_dataset(files[0], decode_times=True, engine="netcdf4") as chk:
            absent = [v for v in keep if v not in chk.variables]
        if absent:
            raise MissingForecastData(f"SiB4 forecast files lack {absent}")

        ds = xr.open_mfdataset(
            files, decode_times=True, engine="netcdf4", combine="by_coords",
            parallel=False, data_vars="minimal", coords="minimal", compat="override",
        )[keep]
        try:
            ds["pft_names"] = ds["pft_names"].astype(str)
            lookup = dict(zip(ds["pft_names"].values.astype(str),
                              ds["pft_refnums"].values.astype(int)))
            out = {}
            for name, spec in specs.items():
                sib_var, pft = parse_label(spec.get("variable", name))
                if sib_var not in ds or pft not in lookup:
                    raise MissingForecastData(f"SiB4 forecast cannot resolve '{name}'")
                da_land = build_pft_field_from_nlu(ds, sib_var, lookup[pft])
                da_grid = to_latlon_grid(da_land, ds).sel(
                    lon=slice(s.IBERIA_LON_MIN, s.IBERIA_LON_MAX),
                    lat=slice(s.IBERIA_LAT_MIN, s.IBERIA_LAT_MAX),
                ).sortby("lat").sortby("lon")
                da_year = seasonal_agg(da_grid, list(spec["months"]), agg=spec.get("agg", "mean"))
                da_year = da_year.sel(time=da_year.time.dt.year == s.FORECAST_YEAR)
                out[name] = self.pre._align_to_burn_grid(da_year).load()
            return out
        finally:
            ds.close()
