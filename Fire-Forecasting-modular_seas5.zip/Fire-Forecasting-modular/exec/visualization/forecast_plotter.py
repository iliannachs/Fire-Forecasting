"""Figures of the SEAS5 ensemble forecast (same designs as the original SEAS5 scripts)."""
import matplotlib

matplotlib.use("Agg")   # no display needed on a cluster
import matplotlib.pyplot as plt
import numpy as np

try:   # cartopy is optional; without it the map has no coastlines
    import cartopy.crs as ccrs
    import cartopy.feature as cfeature
except ImportError:
    ccrs = None


class ForecastPlotter:
    def __init__(self, settings, outdir, init_name):
        self.s = settings
        self.outdir = outdir
        self.init = init_name

    def _save(self, fig, name):
        fig.savefig(self.outdir / f"cluster{self.s.CLUSTER_TO_MODEL}_{name}_{self.s.FORECAST_YEAR}.png",
                    dpi=200)
        plt.close(fig)

    def spaghetti(self, ens_df, clim, annual_totals, observed, era5_ref):
        s, y = self.s, self.s.FORECAST_YEAR
        vals = ens_df["predicted_total_ha"].to_numpy()
        mean = float(vals.mean())
        p10, p90 = np.percentile(vals, [10, 90])
        prev = clim.loc[clim["year"] == y - 1, "burned_area"]
        start = float(prev.iloc[0]) if not prev.empty else mean

        fig, ax = plt.subplots(figsize=(15, 6), constrained_layout=True)
        ax.fill_between([y - 1, y], [start, p10], [start, p90],
                        color="steelblue", alpha=0.15, label="10–90th pct range")
        colors = plt.cm.cool((vals - vals.min()) / max(vals.max() - vals.min(), 1))
        for c, v in zip(colors, vals):
            ax.plot([y - 1, y], [start, v], color=c, alpha=0.4, linewidth=0.8)
            ax.scatter(y, v, color=c, s=25, alpha=0.7, zorder=3)

        hist = clim[clim["year"] < y]
        ax.plot(hist["year"], hist["burned_area"], "-o", color="#1f77b4", linewidth=2,
                markersize=5, label=f"Observed ({hist['year'].min()}-{hist['year'].max()})", zorder=5)
        if annual_totals is not None:
            ax.plot(annual_totals.index, annual_totals["predicted"], "--", color="gray",
                    linewidth=1.4, alpha=0.8, label="ERA5-driven model", zorder=4)
        ax.plot([y - 1, y], [start, mean], color="black", linewidth=2.5, zorder=6,
                label="SEAS5 ensemble mean")
        ax.scatter(y, mean, color="black", marker="D", s=100, zorder=7)
        if np.isfinite(era5_ref):
            ax.scatter(y, era5_ref, color="crimson", marker="x", s=140, linewidths=2.5,
                       zorder=8, label=f"ERA5-driven {y}")
        if np.isfinite(observed):
            ax.scatter(y, observed, color="darkorange", marker="*", s=250, zorder=9,
                       label=f"Observed {y}  ({observed:,.0f} ha)")

        t0, t1 = min(s.TEST_YEARS), max(s.TEST_YEARS)
        ax.axvspan(t0 - 0.5, t1 + 0.5, color="#dce8f5", alpha=0.4, label="Test period")
        first = int(clim["year"].min())
        ax.set_xlim(first - 0.5, y + 0.5)
        ax.set_xticks(np.arange(first, y + 1, 5))
        ax.set_ylim(bottom=0)
        ax.set_xlabel("Year", fontsize=12)
        ax.set_ylabel("JJA burned area (ha)", fontsize=12)
        ax.set_title(f"Cluster {s.CLUSTER_TO_MODEL} ({s.EXPERIMENT_NAME}): observed + "
                     f"SEAS5 {self.init} forecast ({len(vals)} members)", fontsize=13)
        ax.grid(True, linestyle="--", linewidth=0.4, alpha=0.5)
        ax.legend(loc="upper left", fontsize=9, framealpha=0.9)
        self._save(fig, "spaghetti_seas5")

    def violin(self, ens_df, observed, era5_ref):
        s = self.s
        vals = ens_df["predicted_total_ha"].to_numpy()
        mean, median = float(vals.mean()), float(np.median(vals))

        fig, ax = plt.subplots(figsize=(7, 6), constrained_layout=True)
        parts = ax.violinplot(vals, positions=[1], widths=0.6, showmedians=False, showextrema=False)
        for pc in parts["bodies"]:
            pc.set_facecolor("steelblue")
            pc.set_alpha(0.5)
        ax.boxplot(vals, positions=[1], widths=0.25, patch_artist=True,
                   boxprops=dict(facecolor="steelblue", alpha=0.6),
                   medianprops=dict(color="white", linewidth=2),
                   flierprops=dict(marker="o", markersize=4, markerfacecolor="steelblue", alpha=0.6))
        ax.scatter(np.ones(len(vals)), vals, color="steelblue", alpha=0.5, s=20, zorder=3)
        ax.axhline(mean, color="black", linewidth=1.8, linestyle="--",
                   label=f"Ensemble mean  {mean:,.0f} ha")
        if np.isfinite(era5_ref):
            ax.axhline(era5_ref, color="crimson", linewidth=1.8, linestyle=":",
                       label=f"ERA5-driven  {era5_ref:,.0f} ha")
        if np.isfinite(observed):
            ax.axhline(observed, color="darkorange", linewidth=1.8, linestyle="-.",
                       label=f"Observed  {observed:,.0f} ha")
        ax.set_xticks([1])
        ax.set_xticklabels([f"SEAS5\n{self.init}"])
        ax.set_ylabel("JJA burned area (ha)", fontsize=12)
        ax.set_title(f"Cluster {s.CLUSTER_TO_MODEL}: ensemble distribution {s.FORECAST_YEAR}\n"
                     f"n={len(vals)}, mean={mean:,.0f} ha, median={median:,.0f} ha", fontsize=11)
        ax.legend(fontsize=9, framealpha=0.9)
        ax.grid(True, axis="y", linestyle="--", linewidth=0.4, alpha=0.5)
        ax.set_ylim(bottom=0)
        self._save(fig, "violin_box_seas5")

    def percentile_bins(self, ens_df):
        s = self.s
        counts = (ens_df.groupby("percentile_bin", observed=False)["ensemble"].count()
                  .reindex(s.PERCENTILE_LABELS, fill_value=0))
        n = len(ens_df)
        fig, ax = plt.subplots(figsize=(8, 5), constrained_layout=True)
        colors = plt.cm.RdYlBu_r(np.linspace(0.1, 0.9, len(s.PERCENTILE_LABELS)))
        bars = ax.bar(s.PERCENTILE_LABELS, counts.values, color=colors, edgecolor="white")
        for bar, c in zip(bars, counts.values):
            if c > 0:
                ax.text(bar.get_x() + bar.get_width() / 2, bar.get_height() + 0.3,
                        f"{c}\n({100 * c / n:.0f}%)", ha="center", va="bottom", fontsize=9)
        ax.set_xlabel("Percentile bin (relative to the observed climatology)", fontsize=11)
        ax.set_ylabel("Number of ensemble members", fontsize=11)
        ax.set_title(f"Cluster {s.CLUSTER_TO_MODEL}: SEAS5 {self.init} – severity distribution\n"
                     f"({n} members)", fontsize=12)
        ax.set_ylim(0, max(counts.values) * 1.25 + 1)
        ax.grid(True, axis="y", linestyle="--", linewidth=0.4, alpha=0.5)
        self._save(fig, "percentile_bins_seas5")

    def spatial_mean(self, pixel_df, burn_05):
        """Ensemble-mean predicted burned area per pixel (pixels missing in a member count as 0)."""
        s = self.s
        n = pixel_df["ensemble"].nunique()
        grid = (pixel_df.groupby(["lat", "lon"])["predicted"].sum() / n).to_xarray()
        grid = grid.reindex(lat=burn_05.lat.values, lon=burn_05.lon.values,
                            method="nearest", tolerance=1e-6)
        vmax = max(float(np.nanpercentile(grid.values, 98)), 1.0)

        if ccrs is not None:
            fig = plt.figure(figsize=(10, 6))
            ax = fig.add_subplot(1, 1, 1, projection=ccrs.PlateCarree())
            ax.set_extent([s.IBERIA_LON_MIN, s.IBERIA_LON_MAX, s.IBERIA_LAT_MIN, s.IBERIA_LAT_MAX],
                          crs=ccrs.PlateCarree())
            ax.add_feature(cfeature.LAND, facecolor="0.95")
            ax.add_feature(cfeature.OCEAN, facecolor="white")
            ax.add_feature(cfeature.COASTLINE, linewidth=0.8)
            ax.add_feature(cfeature.BORDERS, linewidth=0.6)
            gl = ax.gridlines(draw_labels=True, linewidth=0.3, alpha=0.4)
            gl.top_labels = gl.right_labels = False
            kw = {"transform": ccrs.PlateCarree()}
        else:
            fig, ax = plt.subplots(figsize=(10, 6))
            ax.set_xlabel("Longitude")
            ax.set_ylabel("Latitude")
            kw = {}

        im = ax.pcolormesh(grid.lon.values, grid.lat.values, grid.values,
                           cmap="YlOrRd", vmin=0, vmax=vmax, shading="auto", **kw)
        cbar = plt.colorbar(im, ax=ax, orientation="vertical", pad=0.03, shrink=0.85)
        cbar.set_label("Ensemble-mean predicted burned area (ha)", fontsize=10)
        ax.set_title(f"Cluster {s.CLUSTER_TO_MODEL}: SEAS5 {self.init} ensemble-mean JJA "
                     f"burned area {s.FORECAST_YEAR}\n({n} members)", fontsize=12)
        fig.tight_layout()
        self._save(fig, "spatial_mean_seas5")
