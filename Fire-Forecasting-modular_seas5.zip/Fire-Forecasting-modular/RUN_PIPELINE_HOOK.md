# Hook for exec/run_pipeline.py

Add this at the end of `run_pipeline.py`, after evaluation/plots. Rename the
variables to the ones used there (preprocessor, experiment, cache, trained
model, feature list, Evaluator):

```python
    # 8. SEAS5 seasonal forecast (optional)
    if getattr(settings, "RUN_SEAS5_FORECAST", False):
        from exec.forecast.forecaster import SeasonalForecaster

        annual_totals = evaluator.annual_totals(df_train, df_test, df_eval)  # with 'predicted'
        SeasonalForecaster(settings, preprocessor, experiment, cache).run(
            model, feature_cols, annual_totals
        )
```

## Settings fingerprint (exec/experiment.py)

The new settings (`RUN_SEAS5_FORECAST`, `FORECAST_*`, `SEAS5_*`,
`SIB4_FORECAST_FILE_PATTERN`, `PERCENTILE_*`) do not affect the trained model.
If `experiment.py` puts every UPPERCASE setting into the fingerprint, existing
experiments will now stop with "settings differ". Exclude these names from the
fingerprint, e.g.:

```python
FORECAST_ONLY_PREFIXES = ("RUN_SEAS5_FORECAST", "FORECAST_", "SEAS5_",
                          "SIB4_FORECAST_", "PERCENTILE_")
scientific = {k: v for k, v in snapshot.items()
              if not k.startswith(FORECAST_ONLY_PREFIXES)}
```
